from flask import Flask, render_template, request, redirect, url_for, session
from questions import questions
import random
import os

app = Flask(__name__)
app.secret_key = "supersecretkey"


@app.route('/')
def index():
    return render_template("index.html")


@app.route('/start/<mode>')
def start(mode):
    total_questions = len(questions)

    indices = list(range(total_questions))
    random.shuffle(indices)

    # exam mode capped at 60 questions
    if mode == "exam" and total_questions > 60:
        indices = indices[:60]

    # reset tracking every new session
    session['total_in_session'] = len(indices)
    session['mode'] = mode
    session['remaining'] = indices  # pool of active questions
    session['score'] = 0
    session['correct'] = 0
    session['wrong'] = 0
    session['wrong_once'] = []      # reset wrong
    session['correct_set'] = []     # reset correct
    session['wrong_questions'] = {} # reset wrong questions for review
    session['last_feedback'] = None
    session['repeat_flag'] = False

    return redirect(url_for('quiz'))


@app.route('/quiz', methods=['GET', 'POST'])
def quiz():
    if 'remaining' not in session or not session['remaining']:
        return redirect(url_for('summary'))

    remaining = session['remaining']
    current = remaining[0]
    mode = session.get('mode', 'study')
    repeat_flag = session.get('repeat_flag', False)

    if request.method == 'POST':
        selected = request.form.get('answer')
        correct_answer = questions[current]['answer']

        wrong_once = set(session.get('wrong_once', []))
        correct_set = set(session.get('correct_set', []))
        wrong_questions = session.get('wrong_questions', {})

        if selected == correct_answer:
            session['last_feedback'] = ("correct", None)
            if current not in correct_set:
                correct_set.add(current)
                session['correct_set'] = list(correct_set)
            # always remove once answered correctly
            remaining.pop(0)
        else:
            session['last_feedback'] = ("wrong", correct_answer)

            # Save for review
            if current not in wrong_questions:
                wrong_questions[current] = {
                    'question': questions[current]['question'],
                    'options': questions[current]['options'],
                    'correct_answer': correct_answer,
                    'your_answer': selected
                }
                session['wrong_questions'] = wrong_questions

            if current not in wrong_once:
                # First wrong attempt
                wrong_once.add(current)
                session['wrong_once'] = list(wrong_once)
                repeat_flag = False
                if mode == "exam":
                    remaining.pop(0)  # in exam, move on
                else:
                    # in study, reinsert for retry
                    remaining.insert(random.randint(1, len(remaining)), remaining.pop(0))
            else:
                # Repeated wrong attempt
                repeat_flag = True
                session['repeat_flag'] = True
                if mode == "exam":
                    remaining.pop(0)  # exam just removes
                else:
                    # study reinserts again
                    remaining.insert(random.randint(1, len(remaining)), remaining.pop(0))

        session['remaining'] = remaining
        return redirect(url_for('quiz'))

    # GET: show question
    q = questions[current]
    options = q['options'].copy()
    random.shuffle(options)

    feedback = session.get('last_feedback')
    session['last_feedback'] = None

    # progress capped by total questions in session
    answered = len(set(session.get('correct_set', []))) + len(set(session.get('wrong_once', [])))
    total = session.get('total_in_session', len(questions))
    progress = min(answered + 1, total)

    session['repeat_flag'] = False

    return render_template(
        "quiz.html",
        q=q,
        options=options,
        number=progress,
        total=total,
        correct_count=len(set(session.get('correct_set', []))),
        wrong_count=len(set(session.get('wrong_once', []))),
        feedback=feedback,
        repeat=repeat_flag
    )


@app.route('/summary')
def summary():
    correct_set = set(session.get('correct_set', []))
    wrong_once = set(session.get('wrong_once', []))
    wrong_questions = session.get('wrong_questions', {})
    total_in_session = session.get('total_in_session', 0)
    mode = session.get('mode', 'study')

    if mode == "exam":
        wrong = len(wrong_once)
        correct = total_in_session - wrong
        score = correct
    else:
        correct = len(correct_set)
        wrong = len(wrong_once)
        score = correct

    return render_template(
        "summary.html",
        score=score,
        total=total_in_session,
        correct=correct,
        wrong=wrong,
        mode=mode,
        wrong_questions=wrong_questions
    )


if __name__ == '__main__':
    port = int(os.environ.get("PORT", 8080))
    app.run(host="0.0.0.0", port=port)
